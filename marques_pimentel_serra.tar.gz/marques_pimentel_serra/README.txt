Los integrantes del grupo son Alvaro Pimentel, Andreu Marqués Goyes y Gregori Serra.

Observaciones: No se ha añadido contenido extra y las pruebas realizadas
para comprobar el correcto funcionamiento del programa son las mostradas
en los documentos adjuntos en Aula Digital. Dichas pruebas salieron con 
el resultado esperado y correcto.
